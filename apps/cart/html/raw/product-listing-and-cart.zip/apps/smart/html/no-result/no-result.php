<!------- Smart Header Include File---------->
<?php include '../includes/smart-header.php'; ?>
<!------- Smart Header Include File end---------->


<div class="container-middle">
	    <div class="row w-100">
			<div class="col-12">
				<img src="../../../../images/no-result.png" class="img-fluid d-block mx-auto">
				<div class="mt15 mt-md30  f-md-24 f-20 lato-font">No Result found for 'Email Marketing'</div>
				<div class="grey mt15 f-14">We can’t find your serach..please check the spelling.</br>
					 Visit our <a href="#" class="p-blue-clr t-decoration-none">Smart</a> page or try a different <a href="#" class="p-blue-clr t-decoration-none"> keyword</a></div>
			</div>
		</div>
</div>



<!------- Smart Footer Include File---------->
<?php include '../includes/smart-footer.php'; ?>
<!------- Smart Footer Include File end ---------->