<!------- Smart Header Include File---------->
<?php include '../includes/smart-header.php'; ?>
<!------- Smart Header Include File end---------->

<div class="container-middle">
	    <div class="row w-100 no-gutters">
			<div class="col-12">
				<img src="<?php echo $basedir; ?>images/access-denied.png" class="img-fluid d-block mx-auto">
				<h5 class="mt15 mt-md30 w700"><a href="#" data-toggle="modal" data-target="#PaidFeatureModal">Access Denied</a></h5>
					<div class="grey mt10 f-14 mb-md30 mb15">We are sorry, you do not have permission to view<br class="d-none d-md-block">
					the requested content</div>
			</div>
		</div>
</div>

<!------- Smart Footer Include File---------->
<?php include '../includes/smart-footer.php'; ?>
<!------- Smart Footer Include File end ---------->